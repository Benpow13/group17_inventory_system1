document.addEventListener("DOMContentLoaded", () => {
    const cartItemsContainer = document.getElementById('cart-items');
    const subtotalPrice = document.getElementById('subtotal-price');
    const totalPrice = document.getElementById('total-price');
    const clearCartButton = document.getElementById('clear-cart');
    const shippingCost = 5.00;

    
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    
    function renderCart() {
        cartItemsContainer.innerHTML = '';

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = `<p class="empty-cart-message">Your cart is empty. Start adding items from the shop!</p>`;
            subtotalPrice.textContent = "£0.00";
            totalPrice.textContent = `£${shippingCost.toFixed(2)}`;
            return;
        }

        let subtotal = 0;

        cart.forEach((item, index) => {
            const itemName = item.name || "Unnamed Product";
            const itemPrice = item.price || 0;
            const itemQuantity = item.quantity || 1;
            const itemImage = item.image || 'placeholder.jpg';
            const itemTotal = itemPrice * itemQuantity;

            subtotal += itemTotal;

            const itemDiv = document.createElement('div');
            itemDiv.classList.add('cart-item');
            itemDiv.innerHTML = `
                <img src="${itemImage}" alt="${itemName}" class="cart-item-image">
                <div class="cart-item-details">
                    <h4>${itemName}</h4>
                    <p>Quantity: ${itemQuantity}</p>
                    <p class="price">£${itemTotal.toFixed(2)}</p>
                    <button class="remove-item modern-button secondary-button" data-index="${index}">Remove</button>
                </div>
            `;
            cartItemsContainer.appendChild(itemDiv);
        });

        subtotalPrice.textContent = `£${subtotal.toFixed(2)}`;
        totalPrice.textContent = `£${(subtotal + shippingCost).toFixed(2)}`;
    }

    
    function clearCart() {
        cart = [];
        localStorage.removeItem('cart');
        renderCart();
        alert("Cart cleared successfully!");
    }

    
    clearCartButton.addEventListener('click', clearCart);


    cartItemsContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('remove-item')) {
            const index = e.target.dataset.index;
            cart.splice(index, 1);
            localStorage.setItem('cart', JSON.stringify(cart));
            renderCart();
        }
    });

    
    renderCart();
    // checkout.js
document.getElementById('checkout-button').addEventListener('click', () => {
    // Get the total amount from the checkout page
    const totalAmount = document.getElementById('total-price').textContent.replace('£', '');
    // Save it in localStorage
    localStorage.setItem('totalAmount', totalAmount);
});

});