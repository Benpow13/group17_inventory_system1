// payment.js
document.addEventListener('DOMContentLoaded', () => {
    // Retrieve the total amount from localStorage
    const totalAmount = localStorage.getItem('totalAmount') || '0.00';
    const shippingCost = 5.00; // Fixed shipping cost
    const updatedTotal = (parseFloat(totalAmount) + shippingCost).toFixed(2);

    // Update the payment summary in the payment.html
    document.getElementById('subtotal-amount').textContent = `£${totalAmount}`;
    document.getElementById('total-amount').textContent = `£${updatedTotal}`;
});