const cart = JSON.parse(localStorage.getItem('cart')) || [];
const cartCount = document.getElementById('cart-count');
const productGrid = document.getElementById('product-grid');
const searchInput = document.getElementById('search');

function updateCartCount() {
    cartCount.textContent = cart.length;
}

document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', () => {
        const product = button.closest('.product');
        const id = product.dataset.id;
        const name = product.dataset.name;
        const price = parseFloat(product.dataset.price);

        cart.push({ id, name, price });
        localStorage.setItem('cart', JSON.stringify(cart));
        updateCartCount();
        alert(`${name} added to cart!`);
    });
});


document.querySelectorAll('.filter-button').forEach(button => {
    button.addEventListener('click', () => {
        const category = button.dataset.category;
        document.querySelectorAll('.product').forEach(product => {
            product.style.display = 
                category === 'all' || product.dataset.category === category ? 'block' : 'none';
        });
    });
});


searchInput.addEventListener('input', e => {
    const query = e.target.value.toLowerCase();
    document.querySelectorAll('.product').forEach(product => {
        const name = product.dataset.name.toLowerCase();
        product.style.display = name.includes(query) ? 'block' : 'none';
    });
});

updateCartCount();