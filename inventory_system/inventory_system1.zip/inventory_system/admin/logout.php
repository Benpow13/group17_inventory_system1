<?php
session_start(); // Start the session
session_destroy(); // Correct function to destroy the session

// Redirect using JavaScript
echo '<script type="text/javascript">
    window.location = "index.php";
</script>';
?>
