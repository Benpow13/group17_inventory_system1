<?php
session_start();
include "../../user/connection.php";

$company_name = $_GET["company_name"];
$product_name = $_GET["product_name"];
$unit = $_GET["unit"];
$packing_size = $_GET["packing_size"];
$price = $_GET["price"];
$qty = $_GET["qty"];
$total = $_GET["total"];

if (isset($_SESSION['cart'])) {
    $check_available = check_duplicate_product($company_name, $product_name, $unit, $packing_size);
    $available_qty = 0;

    if ($check_available == 0) {
        $available_qty = check_qty($company_name, $product_name, $unit, $packing_size, $link);
        if ($available_qty >= $qty) {
            $product = array(
                "company_name" => $company_name,
                "product_name" => $product_name,
                "unit" => $unit,
                "packing_size" => $packing_size,
                "price" => $price,
                "qty" => $qty
            );
            $_SESSION['cart'][] = $product;
        } else {
            echo "Entered qty is not available";
        }
    } else {
        $existing_qty = check_the_qty($company_name, $product_name, $unit, $packing_size);
        $new_total_qty = $existing_qty + $qty;
        $available_qty = check_qty($company_name, $product_name, $unit, $packing_size, $link);

        if ($available_qty >= $new_total_qty) {
            $product_index = check_product_no_session($company_name, $product_name, $unit, $packing_size);
            $_SESSION['cart'][$product_index]["qty"] = $new_total_qty;
        } else {
            echo "Entered qty exceeds available stock";
        }
    }
} else {
    $available_qty = check_qty($company_name, $product_name, $unit, $packing_size, $link);
    if ($available_qty >= $qty) {
        $_SESSION['cart'] = array(array(
            "company_name" => $company_name,
            "product_name" => $product_name,
            "unit" => $unit,
            "packing_size" => $packing_size,
            "price" => $price,
            "qty" => $qty
        ));
    } else {
        echo "Entered qty is not available";
    }
}

function check_qty($company_name, $product_name, $unit, $packing_size, $link) {
    $product_qty = 0;
    $query = "SELECT product_qty FROM stock_master WHERE 
              product_company = '$company_name' AND 
              product_name = '$product_name' AND 
              product_unit = '$unit' AND 
              packing_size = '$packing_size'";
    $res = mysqli_query($link, $query);
    if ($res && $row = mysqli_fetch_assoc($res)) {
        $product_qty = $row["product_qty"];
    }
    return $product_qty;
}

function check_duplicate_product($company_name, $product_name, $unit, $packing_size) {
    $found = 0;
    foreach ($_SESSION['cart'] as $item) {
        if (
            $item["company_name"] === $company_name &&
            $item["product_name"] === $product_name &&
            $item["unit"] === $unit &&
            $item["packing_size"] === $packing_size
        ) {
            $found = 1;
            break;
        }
    }
    return $found;
}

function check_the_qty($company_name, $product_name, $unit, $packing_size) {
    $qty_found = 0;
    foreach ($_SESSION['cart'] as $item) {
        if (
            $item["company_name"] === $company_name &&
            $item["product_name"] === $product_name &&
            $item["unit"] === $unit &&
            $item["packing_size"] === $packing_size
        ) {
            $qty_found = $item["qty"];
            break;
        }
    }
    return $qty_found;
}

function check_product_no_session($company_name, $product_name, $unit, $packing_size) {
    foreach ($_SESSION['cart'] as $index => $item) {
        if (
            $item["company_name"] === $company_name &&
            $item["product_name"] === $product_name &&
            $item["unit"] === $unit &&
            $item["packing_size"] === $packing_size
        ) {
            return $index;
        }
    }
    return -1; // Should not happen if check_duplicate_product is used correctly
}
?>
