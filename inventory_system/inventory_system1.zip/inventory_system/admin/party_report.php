<?php
include "header.php";
include "../user/connection.php"; // Assume connection.php defines $pdo (PDO instance)

// Fetch all parties for the dropdown using PDO
$partyQuery = "SELECT id, firstname, lastname FROM party_info";
$statement = $pdo->prepare($partyQuery); // Prepare the statement
$statement->execute(); // Execute the query
$parties = $statement->fetchAll(PDO::FETCH_ASSOC); // Fetch results as associative array
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Party Report</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <div class="container">
        <h1>Party Report</h1>
        <form method="GET" action="party_report.php">
            <label for="party">Select a Party:</label>
            <select name="party_id" id="party" required>
                <option value="">-- Select a Party --</option>
                <?php
                if (!empty($parties)) {
                    foreach ($parties as $party) {
                        echo "<option value='{$party['id']}'>{$party['firstname']} {$party['lastname']}</option>";
                    }
                } else {
                    echo "<option value=''>No parties available</option>";
                }
                ?>
            </select>
            <button type="submit">View Report</button>
        </form>

        <?php
        
        if (isset($_GET['party_id'])) {
            $party_id = intval($_GET['party_id']);

            // Fetch the data for the selected party
            $query = "SELECT * FROM party_info WHERE id = :party_id";
            $statement = $pdo->prepare($query); // Prepare the statement
            $statement->bindParam(':party_id', $party_id, PDO::PARAM_INT); // Bind the parameter
            $statement->execute(); // Execute the query
            $partyDetails = $statement->fetchAll(PDO::FETCH_ASSOC); // Fetch results as associative array

            if (!empty($partyDetails)) {
                echo "<h2>Party Details</h2>";
                echo "<table class='party-table'>";
                echo "<thead>
                        <tr>
                            <th>ID</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Contact</th>
                            <th>Business Name</th>
                            <th>Address</th>
                            <th>City</th>
                        </tr>
                      </thead>";
                echo "<tbody>";
                foreach ($partyDetails as $detail) {
                    echo "<tr>
                            <td>{$detail['id']}</td>
                            <td>{$detail['firstname']}</td>
                            <td>{$detail['lastname']}</td>
                            <td>{$detail['contact']}</td>
                            <td>{$detail['businessname']}</td>
                            <td>{$detail['address']}</td>
                            <td>{$detail['city']}</td>
                          </tr>";
                }
                echo "</tbody>";
                echo "</table>";
            } else {
                echo "<p class='no-data'>No details found for the selected party.</p>";
            }
        }
        ?>
    </div>
</body>
</html>

